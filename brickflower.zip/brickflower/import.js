// import.js
//const a = 1;
//module.exports = a;

console.log("import?");